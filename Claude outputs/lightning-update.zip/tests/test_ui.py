"""The HTML UI end to end: every page renders, forms create real records."""

import re

import pytest
from fastapi.testclient import TestClient

from lightning.ui.web import create_app


@pytest.fixture
def client(c):
    return TestClient(create_app(c))


def test_welcome_then_first_account(client, c):
    r = client.get("/")
    assert r.status_code == 200 and "Let's start with your accounts" in r.text
    r = client.post("/accounts/new", data={"name": "CIB Current", "institution": "CIB", "account_type": "BANK",
                                           "opening_date": "2026-09-01", "opening_balance": "50,000"})
    assert r.status_code == 200 and "CIB-CUR-EGP · CIB Current" in r.text
    r = client.get("/")
    assert "Net worth" in r.text and "50,000.00" in r.text


def test_full_flow(client, c):
    client.post("/accounts/new", data={"name": "CIB Current", "account_type": "BANK", "institution": "CIB",
                                       "opening_date": "2026-09-01", "opening_balance": "50000"})
    client.post("/accounts/new", data={"name": "Wallet", "account_type": "CASH",
                                       "opening_date": "2026-09-01", "opening_balance": "1000"})
    cib = c.accounts.get_by_code("CIB-CUR-EGP")
    wallet = c.accounts.get_by_code("WALLET-CSH-EGP")
    food = c.categories.get_by_code("EXP.PERSONAL.FOOD")

    r = client.get("/transactions/new?kind=out")
    assert r.status_code == 200 and "Food &amp; Groceries" in r.text and "EXP.PERSONAL.FOOD ·" not in r.text

    r = client.post("/transactions/new?kind=out", data={"date": "2026-09-25", "account_id": cib.id, "amount": "450",
                                                        "category_id": food.id, "counterparty": "Carrefour",
                                                        "description": "Groceries", "notes": ""})
    assert r.status_code == 200 and "OUT-2026-09-25-001" in r.text
    txn_id = int(re.search(r"/transactions/(\d+)/edit", r.text).group(1))

    r = client.post("/transactions/new?kind=transfer", data={"date": "2026-09-26", "account_id": cib.id,
                                                             "to_account_id": wallet.id, "amount": "2000"})
    assert "TRF-2026-09-26-001" in r.text

    # validation errors re-render the form with the message and the typed values
    r = client.post("/transactions/new?kind=out", data={"date": "26/09/2026", "account_id": cib.id,
                                                        "amount": "12", "category_id": food.id})
    assert r.status_code == 400 and "yyyy-mm-dd" in r.text and 'value="12"' in r.text

    r = client.get("/transactions?q=carrefour")
    assert "OUT-2026-09-25-001" in r.text and "1 found" in r.text

    r = client.post(f"/transactions/{txn_id}/edit", data={"date": "2026-09-25", "account_id": cib.id,
                                                          "amount": "540", "category_id": food.id})
    assert "Updated OUT-2026-09-25-001" in r.text
    assert c.reporting.account_balance(cib.id) == 50000 - 540 - 2000

    r = client.post(f"/transactions/{txn_id}/void")
    assert "void" in r.text
    r = client.post(f"/transactions/{txn_id}/restore")
    assert "restored" in r.text

    r = client.get(f"/accounts/{cib.id}")
    assert r.status_code == 200 and "47,460.00" in r.text

    r = client.get("/?month=2026-09")
    assert "Checks out to 0.00" in r.text

    r = client.post(f"/accounts/{wallet.id}/deactivate")
    assert "Move the balance" in r.text

    assert client.get("/t/OUT-2026-09-25-001", follow_redirects=False).status_code == 303


@pytest.mark.parametrize("path", ["/", "/accounts", "/accounts/new", "/transactions", "/transactions/new?kind=in",
                                  "/transactions/new?kind=transfer", "/categories", "/settings",
                                  "/categories/new?parent=1"])
def test_pages_render(client, setup, path):
    assert client.get(path).status_code == 200


def test_not_found(client):
    assert client.get("/accounts/999").status_code == 404
    assert client.get("/t/OUT-2000-01-01-001").status_code == 404


def test_category_pages(client, c):
    personal = c.categories.get_by_code("EXP.PERSONAL")
    r = client.post(f"/categories/new?parent={personal.id}", data={"name": "Pets", "code": ""})
    assert "Added Personal › Pets" in r.text
    pets = c.categories.get_by_code("EXP.PERSONAL.PETS")
    r = client.post(f"/categories/{pets.id}/edit", data={"name": "Pets & Vet", "code": "PETS", "active": "1"})
    assert "Category saved" in r.text and c.categories.get(pets.id).name == "Pets & Vet"


def test_backup_button(client):
    r = client.post("/settings/backup")
    assert "Backup saved as lightning_" in r.text


def test_register_entry(client, c, setup):
    accounts, cats = setup
    wallet, cib = accounts["wallet"], accounts["cib"]
    food, salary = cats["EXP.PERSONAL.FOOD"], cats["INC.SALARY"]
    page = client.get(f"/accounts/{wallet.id}")
    assert 'action="/accounts/%d/register"' % wallet.id in page.text and "Transfer ↔ another account" in page.text
    assert "EXP.PERSONAL" not in page.text  # plain names only

    r = client.post(f"/accounts/{wallet.id}/register", data={"date": "2026-09-20", "payee": "Carrefour",
                    "choice": f"cat:{food.id}", "payment": "150", "deposit": "", "notes": "milk"})
    assert "Saved OUT-2026-09-20-001" in r.text and "Personal › Food &amp; Groceries" in r.text
    assert c.reporting.account_balance(wallet.id) == 1200 - 150

    r = client.post(f"/accounts/{wallet.id}/register", data={"date": "2026-09-21", "payee": "",
                    "choice": f"acct:{cib.id}", "payment": "", "deposit": "500"})
    assert "Saved TRF-2026-09-21-001" in r.text
    assert c.reporting.account_balance(wallet.id) == 1200 - 150 + 500
    assert c.reporting.account_balance(cib.id) == 50000 - 500

    # wrong column for the category -> friendly error, typed values kept
    r = client.post(f"/accounts/{wallet.id}/register", data={"date": "2026-09-22", "payee": "Employer",
                    "choice": f"cat:{salary.id}", "payment": "99", "deposit": ""})
    assert r.status_code == 400 and "put the amount under Deposit" in r.text and 'value="99"' in r.text

    # the payee is remembered with its category
    page = client.get(f"/accounts/{wallet.id}")
    assert "Carrefour" in page.text and f"cat:{food.id}" in page.text


def test_account_form_has_no_class_picker(client):
    r = client.get("/accounts/new")
    assert "cash_class_code" not in r.text and "Liquid Cash › Bank Balance" in r.text
    assert "Credit card" not in r.text and "Loan" not in r.text


def test_categories_page_is_plain(client):
    r = client.get("/categories")
    assert "Food &amp; Groceries" in r.text and "EXP.PERSONAL.FOOD" not in r.text
