// Small helpers only — no financial logic lives in the browser.
document.addEventListener("click", (e) => {
  const btn = e.target.closest("[data-date]");
  if (!btn) return;
  e.preventDefault();
  const input = document.getElementById(btn.dataset.target || "date");
  const d = new Date();
  d.setDate(d.getDate() - Number(btn.dataset.date || 0));
  const pad = (n) => String(n).padStart(2, "0");
  input.value = `${d.getFullYear()}-${pad(d.getMonth() + 1)}-${pad(d.getDate())}`;  // yyyy-mm-dd
});

// Account form: show where the chosen type appears on the dashboard.
const typeSelect = document.getElementById("account_type");
if (typeSelect) {
  const groups = JSON.parse(typeSelect.dataset.groups || "{}");
  const target = document.getElementById("group_name");
  typeSelect.addEventListener("change", () => {
    if (target) target.textContent = groups[typeSelect.value] || "";
  });
}

// Register: a payee used before fills in its last category.
const payee = document.getElementById("payee");
const choice = document.getElementById("choice");
if (payee && choice) {
  const known = JSON.parse(payee.dataset.payees || "{}");
  payee.addEventListener("change", () => {
    const value = known[payee.value];
    if (value && !choice.value) choice.value = value;
  });
}
