from __future__ import annotations

from fastapi import APIRouter, Request

from lightning.accounts.domain import DEFAULT_CASH_CLASS, OFFERED_TYPES, TYPE_LABELS
from lightning.core.dates import fmt_date, today
from lightning.categories.domain import Movement
from lightning.core.errors import LightningError

from ..web import container, redirect, render

router = APIRouter(prefix="/accounts")

FIELDS = ("name", "institution", "account_type", "opening_date", "opening_balance", "code", "last4", "notes")


def _form_context(request: Request, values: dict, account=None, error: LightningError | None = None):
    c = container(request)
    return dict(
        values=values,
        account=account,
        types=[(t.value, TYPE_LABELS[t]) for t in OFFERED_TYPES],
        # where each type shows up in "What your wealth is made of", in plain words
        groups={t.value: c.assets.display_name(c.assets.get_class_by_code(DEFAULT_CASH_CLASS[t]).id)
                for t in OFFERED_TYPES},
        error=error.message if error else "",
        error_field=(error.field or "") if error else "",
    )


@router.get("")
async def list_accounts(request: Request):
    c = container(request)
    rows = []
    for account in c.accounts.list():
        rows.append((account, c.reporting.account_balance(account.id, today()),
                     c.transactions.count_for_account(account.id)))
    net_worth = c.reporting.net_worth(today())
    return render(request, "accounts/list.html", rows=rows, net_worth=net_worth)


@router.get("/new")
async def new_account(request: Request):
    values = {"account_type": request.query_params.get("type", "BANK"), "opening_date": fmt_date(today()),
              "opening_balance": ""}
    return render(request, "accounts/form.html", **_form_context(request, values))


@router.post("/new")
async def create_account(request: Request):
    c = container(request)
    form = await request.form()
    values = {k: str(form.get(k, "")) for k in FIELDS}
    try:
        account = c.account_flows.open_account(**values)
    except LightningError as exc:
        return render(request, "accounts/form.html", status_code=400, **_form_context(request, values, error=exc))
    return redirect(f"/accounts/{account.id}", f"Account {account.label} is ready.")


ENTRY_FIELDS = ("date", "payee", "choice", "notes", "payment", "deposit")


def _register(request: Request, account_id: int, entry: dict | None = None, error: str = "", error_field: str = "",
              status_code: int = 200):
    """The account page: a register with an entry row on top (Actual-style)."""
    c = container(request)
    account = c.accounts.get(account_id)
    date_from = request.query_params.get("from") or account.opening_date
    date_to = request.query_params.get("to") or max(fmt_date(today()), account.opening_date)
    try:
        statement = c.reporting.statement(account_id, date_from, date_to)
    except LightningError as exc:
        statement = c.reporting.statement(account_id, account.opening_date, fmt_date(today()))
        error = error or exc.message
    choices = []
    for title, movement in (("Money out", Movement.OUTFLOW), ("Money in", Movement.INFLOW)):
        loose = []
        for group, items in c.categories.groups(movement, include_inactive=False):
            if items:
                choices.append((f"{title} · {group.name}",
                                [(f"cat:{i.id}", ("— " * (i.depth - 2)) + i.name) for i in items]))
            else:
                loose.append((f"cat:{group.id}", group.name))
        if loose:
            choices.append((title, loose))
    others = [a for a in c.accounts.list(active_only=True) if a.id != account.id]
    if others:
        choices.append(("Transfer ↔ another account", [(f"acct:{a.id}", a.label) for a in others]))
    payees = c.transactions.payee_suggestions()
    return render(request, "accounts/detail.html", status_code=status_code, account=account, statement=statement,
                  balance=c.reporting.account_balance(account_id, today()),
                  balance_all=c.reporting.account_balance(account_id),
                  opening=c.account_flows.opening_of(account), group=c.accounts.reporting_group(account),
                  choices=choices, payees={p: f"cat:{cid}" for p, cid in payees.items()},
                  entry=entry or {"date": request.query_params.get("date") or fmt_date(today())},
                  error=error, error_field=error_field)


@router.get("/{account_id:int}")
async def account_detail(request: Request, account_id: int):
    return _register(request, account_id)


@router.post("/{account_id:int}/register")
async def register_entry(request: Request, account_id: int):
    """Save one row typed into the register, then come back ready for the next one."""
    c = container(request)
    form = await request.form()
    entry = {k: str(form.get(k, "")) for k in ENTRY_FIELDS}
    kind, _, raw_id = entry["choice"].partition(":")
    target = int(raw_id) if raw_id.isdigit() else None
    try:
        txn = c.transactions.record_in_account(
            account_id, entry["date"], payment=entry["payment"], deposit=entry["deposit"],
            category_id=target if kind == "cat" else None, other_account_id=target if kind == "acct" else None,
            payee=entry["payee"], notes=entry["notes"])
    except LightningError as exc:
        return _register(request, account_id, entry=entry, error=exc.message, error_field=exc.field or "",
                         status_code=400)
    return redirect(f"/accounts/{account_id}?date={txn.date}", f"Saved {txn.ref}.")


@router.get("/{account_id:int}/edit")
async def edit_account(request: Request, account_id: int):
    c = container(request)
    a = c.accounts.get(account_id)
    values = {
        "name": a.name, "institution": a.institution, "account_type": a.account_type.value,
        "opening_date": a.opening_date, "opening_balance": str(c.account_flows.opening_of(a)),
        "code": a.code, "last4": a.last4 or "",
        "notes": a.notes,
    }
    return render(request, "accounts/form.html", **_form_context(request, values, account=a))


@router.post("/{account_id:int}/edit")
async def update_account(request: Request, account_id: int):
    c = container(request)
    account = c.accounts.get(account_id)
    form = await request.form()
    values = {k: str(form.get(k, "")) for k in FIELDS}
    try:
        account = c.account_flows.update_account(account_id, **values)
    except LightningError as exc:
        return render(request, "accounts/form.html", status_code=400,
                      **_form_context(request, values, account=account, error=exc))
    return redirect(f"/accounts/{account.id}", "Account saved.")


@router.post("/{account_id:int}/deactivate")
async def deactivate(request: Request, account_id: int):
    c = container(request)
    try:
        account = c.account_flows.deactivate(account_id)
    except LightningError as exc:
        return redirect(f"/accounts/{account_id}", exc.message)
    return redirect(f"/accounts/{account.id}", f"{account.label} is now inactive.")


@router.post("/{account_id:int}/reactivate")
async def reactivate(request: Request, account_id: int):
    account = container(request).account_flows.reactivate(account_id)
    return redirect(f"/accounts/{account.id}", f"{account.label} is active again.")
