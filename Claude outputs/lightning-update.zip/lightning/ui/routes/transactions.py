from __future__ import annotations

from fastapi import APIRouter, Request

from lightning.categories.domain import Movement
from lightning.core.dates import fmt_date, parse_month, today
from lightning.core.errors import LightningError, ValidationError
from lightning.core.refs import DOC_LABELS, DocType
from lightning.transactions.domain import TxnFilter

from ..web import container, redirect, render

router = APIRouter()

KINDS = {
    "out": ("Money out", "Spending, bills, fees — money leaving your finances."),
    "in": ("Money in", "Salary, interest, gifts — money entering your finances."),
    "transfer": ("Move money", "Between two of your own accounts. Not income, not spending."),
}
FIELDS = ("date", "account_id", "to_account_id", "amount", "category_id", "description", "counterparty", "notes")
PAGE_SIZE = 50


def _int(value) -> int | None:
    try:
        return int(value) if str(value or "").strip() else None
    except ValueError:
        return None


def _form_context(request: Request, kind: str, values: dict, txn=None, error: LightningError | None = None):
    c = container(request)
    movement = Movement.INFLOW if kind == "in" else Movement.OUTFLOW
    categories = c.categories.pickable(movement) if kind != "transfer" else []
    groups: dict[str, list] = {}
    for cat in categories:
        parent_code = ".".join(cat.code.split(".")[:2])
        groups.setdefault(c.categories.get_by_code(parent_code).name, []).append(cat)
    return dict(
        kind=kind,
        title=KINDS[kind][0],
        hint=KINDS[kind][1],
        values=values,
        txn=txn,
        accounts=c.accounts.list(active_only=True),
        category_groups=groups,
        error=error.message if error else "",
        error_field=(error.field or "") if error else "",
    )


def _save(request: Request, kind: str, values: dict, txn_id: int | None = None):
    t = container(request).transactions
    common = dict(date=values["date"], amount=values["amount"], description=values["description"],
                  notes=values["notes"])
    if kind == "transfer":
        args = dict(from_account_id=_int(values["account_id"]), to_account_id=_int(values["to_account_id"]), **common)
        return t.update_transfer(txn_id, **args) if txn_id else t.record_transfer(**args)
    args = dict(account_id=_int(values["account_id"]), category_id=_int(values["category_id"]),
                counterparty=values["counterparty"], **common)
    if txn_id:
        return t.update_money(txn_id, **args)
    return t.record_inflow(**args) if kind == "in" else t.record_outflow(**args)


@router.get("/transactions")
async def list_transactions(request: Request):
    c = container(request)
    qp = request.query_params
    page = max(1, _int(qp.get("page")) or 1)
    f = TxnFilter(search=qp.get("q", ""), account_id=_int(qp.get("account")), include_void=qp.get("void") == "1",
                  limit=PAGE_SIZE, offset=(page - 1) * PAGE_SIZE)
    error = ""
    if qp.get("type") in DocType.__members__:
        f.types = [DocType(qp["type"])]
    if qp.get("month"):
        try:
            first, last = parse_month(qp["month"])
            f.date_from, f.date_to = fmt_date(first), fmt_date(last)
        except ValidationError as exc:
            error = exc.message
    rows, total = c.transactions.find(f)
    return render(request, "transactions/list.html", rows=rows, total=total, page=page, page_size=PAGE_SIZE,
                  q=qp.get("q", ""), account=qp.get("account", ""), type=qp.get("type", ""),
                  month=qp.get("month", ""), void=qp.get("void", ""), error=error,
                  accounts=c.accounts.list(), types=[(t.value, DOC_LABELS[t]) for t in
                                                     (DocType.IN, DocType.OUT, DocType.TRF, DocType.OPN)])


@router.get("/transactions/new")
async def new_transaction(request: Request):
    kind = request.query_params.get("kind", "out")
    if kind not in KINDS:
        kind = "out"
    c = container(request)
    if not c.accounts.list(active_only=True):
        return redirect("/accounts/new", "Add an account first — then you can record money in and out.")
    values = {k: "" for k in FIELDS}
    values["date"] = request.query_params.get("date") or fmt_date(today())
    values["account_id"] = request.query_params.get("account", "")
    return render(request, "transactions/form.html", **_form_context(request, kind, values))


@router.post("/transactions/new")
async def create_transaction(request: Request):
    kind = request.query_params.get("kind", "out")
    form = await request.form()
    values = {k: str(form.get(k, "")) for k in FIELDS}
    try:
        txn = _save(request, kind if kind in KINDS else "out", values)
    except LightningError as exc:
        return render(request, "transactions/form.html", status_code=400,
                      **_form_context(request, kind, values, error=exc))
    if form.get("again"):
        return redirect(f"/transactions/new?kind={kind}&date={txn.date}&account={values['account_id']}",
                        f"Saved {txn.ref}. Add the next one.")
    return redirect(f"/transactions/{txn.id}", f"Saved {txn.ref}.")


@router.get("/transactions/{txn_id:int}")
async def transaction_detail(request: Request, txn_id: int):
    c = container(request)
    txn = c.transactions.get(txn_id)
    lines = []
    for line in txn.lines:
        lines.append(dict(
            ref=txn.line_ref(line), account=c.accounts.get(line.account_id).label,
            asset=c.assets.get_asset(line.asset_id).code, quantity=line.quantity, amount_base=line.amount_base,
            effect=line.effect.value, category=c.categories.get(line.category_id).label if line.category_id else "",
            memo=line.memo,
        ))
    return render(request, "transactions/detail.html", txn=txn, summary=c.transactions.summarize(txn),
                  lines=lines, history=c.transactions.history(txn_id))


@router.get("/transactions/{txn_id:int}/edit")
async def edit_transaction(request: Request, txn_id: int):
    c = container(request)
    txn = c.transactions.get(txn_id)
    if txn.type == DocType.OPN:
        account_id = txn.lines[0].account_id
        return redirect(f"/accounts/{account_id}/edit", "Opening balances are changed on the account.")
    kind = {DocType.IN: "in", DocType.OUT: "out", DocType.TRF: "transfer"}.get(txn.type)
    if kind is None or txn.is_void:
        return redirect(f"/transactions/{txn_id}", "This transaction cannot be edited.")
    s = c.transactions.summarize(txn)
    values = dict(date=txn.date, account_id=str(s.account_id or ""), to_account_id=str(s.to_account_id or ""),
                  amount=str(abs(s.amount)), category_id=str(s.category_id or ""), description=txn.description,
                  counterparty=txn.counterparty, notes=txn.notes)
    return render(request, "transactions/form.html", **_form_context(request, kind, values, txn=txn))


@router.post("/transactions/{txn_id:int}/edit")
async def update_transaction(request: Request, txn_id: int):
    c = container(request)
    txn = c.transactions.get(txn_id)
    kind = {DocType.IN: "in", DocType.OUT: "out", DocType.TRF: "transfer"}.get(txn.type, "out")
    form = await request.form()
    values = {k: str(form.get(k, "")) for k in FIELDS}
    try:
        txn = _save(request, kind, values, txn_id=txn_id)
    except LightningError as exc:
        return render(request, "transactions/form.html", status_code=400,
                      **_form_context(request, kind, values, txn=txn, error=exc))
    return redirect(f"/transactions/{txn.id}", f"Updated {txn.ref}.")


@router.post("/transactions/{txn_id:int}/void")
async def void_transaction(request: Request, txn_id: int):
    txn = container(request).transactions.void(txn_id)
    return redirect(f"/transactions/{txn.id}", f"{txn.ref} is void — it no longer counts in balances.")


@router.post("/transactions/{txn_id:int}/restore")
async def restore_transaction(request: Request, txn_id: int):
    try:
        txn = container(request).transactions.restore(txn_id)
    except LightningError as exc:
        return redirect(f"/transactions/{txn_id}", exc.message)
    return redirect(f"/transactions/{txn.id}", f"{txn.ref} restored.")


@router.get("/t/{ref}")
async def by_ref(request: Request, ref: str):
    txn = container(request).transactions.get_by_ref(ref)
    return redirect(f"/transactions/{txn.id}")
