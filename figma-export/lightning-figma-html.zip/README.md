# Lightning phone v2.0 for Figma

All screens are the real app on dummy data (Mohab's sample household), 390 px wide.

## What is here
- `png/en`, `png/ar`: every screen at 2x (780 px wide, full page height), English and Arabic (right to left).
  `png/themes`: Home, Budget, Plan and Money in Dendera and Royal Obsidian & Gold.
  Names follow the mockup: 01 Welcome, 02 Your profile, 03 Recovery key, 04 Home, 05 Home first day, 06 Add, 07 A transaction,
  09 to 12 Budget, 13 to 16 Plan, 17 Money, 18 Activity, 19 To review, 20 Investments, 21 One account, 22 Settings.
  (08 is the Dendera Home, in `png/themes`.)
- `html/…`: the same screens as single self-contained HTML files (styles and fonts inside, no scripts) for the html.to.design plugin.
- `tokens/lightning-tokens.tokens-studio.json`: colours, gradients, shadows, type, radii and spacing; the default look plus the
  six paid themes (cotton, dendera, dendera-night, nile, papyrus, royal-obsidian-gold). For the Tokens Studio plugin.
- `brand/`: the mark (colour, flat, on dark), the bundled institution logos, and the fonts (Bricolage Grotesque, Manrope,
  Readex Pro for Arabic; all SIL OFL, see `brand/fonts/LICENSE-FONTS.txt`).

## Ways to work on it in Figma (best first)
1. **Editable layers from the HTML:** install the *html.to.design* plugin (Figma Community), open it, choose to import a file
   (or paste the HTML), drop in one file from `html/en`. You get real frames, text, auto-layout-like groups and colours.
   Import each screen into its own 390 x 844 frame. Not verified inside Figma from here: if a screen imports badly,
   tell me which one and I will adjust the markup.
2. **Tokens:** install *Tokens Studio for Figma*, Tools > Load from file, pick the JSON, then apply the sets to your styles
   and variables (the `theme/…` sets switch the whole look).
3. **Pixel reference:** drag the PNGs onto a page (they are 2x, so set them to 390 wide) and trace or compare.
4. **Icons:** the app uses Lucide icons (stroke 1.75). Use the *Lucide* Figma community plugin rather than tracing.
5. **Fonts:** Bricolage Grotesque and Manrope are in Figma's Google Fonts. Install Readex Pro for Arabic from `brand/fonts` if needed.

## Limits
- Figma cannot be written to from outside its plugins, so there is no live sync: re-run `export_screens.py` after the app changes.
- The first-day Home and the welcome screens are captured from a fresh profile; there is no Dendera first-day screen.
- Screens are static: the Add sheet's keypad and the sheets that open on tap are shown closed, as the page loads.
